##!/bin/sh
#export LINKHOME=~
#export LINKHOME=/devel/nlp/parsers/lg/system-4.1/link-4.1
#alias lgparser=$LGHOME/data/4.0.dict
#alias persianlg=$FA_LGHOME/data/4.0.dict
export FA_LGHOME="~/persianlg"
export LGPARSE_HOME='/usr/bin'
alias persianlg='${LGPARSE_HOME}/link-grammar ${FA_LGHOME}/data/4.0.dict'
