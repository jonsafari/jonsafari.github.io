#!/bin/sh
### Usage:	cat input_file.txt | perl perstem.pl --zwnj --tokenize | ./persianlg.sh
### OR Usage:	echo 'mn rftm'     | perl perstem.pl --zwnj --tokenize | ./persianlg.sh


#export PERSIANLG_HOME="~/public_html/persianlg"
export PERSIANLG_HOME=./


#./perstem.pl --zwnj --tokenize  2>/dev/null	| # morphology; assumes romanized input.  If you want to use Perso-Arabic script in UTF-8, then add the argument ' --input utf8 '
(printf "!width=150\n!max-length=280\n!graphics=1\n!short=8\n!echo=1\n!links=1\n!timeout=5\n\n"; cat; printf "\n\n" )	| # prepends link-grammar width info
#link-parser fa 2>/dev/null			| # link-grammar parsing
link-parser ${PERSIANLG_HOME} 2>/dev/null	| # link-grammar parsing
egrep -v 'Opening|set to|RETURN|Info'		  # eliminates useless lines
